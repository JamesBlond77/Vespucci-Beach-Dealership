resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'
this_is_a_map "yes"


client_scripts {
    "client.lua"
}


data_file 'DLC_ITYP_REQUEST' 'stream/DisneyHackerspace/hackerspace.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/DisneyPraca/lafa2k_halloween.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/DisneyPraca/omegatower.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/DisneyIlha/def_props.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/DisneyBennys/lr_supermod_garage_int.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/DisneyFinalfantasyxv/ffxv_galdinquay.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/DisneyModernhouse/lafa2k_modernhouse.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/DisneyYakuza/yakuza.ytyp'